-- lazy.vim
require("config.lazy")

